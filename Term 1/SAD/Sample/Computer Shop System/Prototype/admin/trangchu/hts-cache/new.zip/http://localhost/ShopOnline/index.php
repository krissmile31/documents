<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/html">

<head>
    <base href="http://localhost/ShopOnline/" />
    <meta charset="UTF-8">
    <title>Trang chủ</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Computer Shop">
    <meta name="author" content="">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="Computer Shop" />
    <link href="admin/themes/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="public/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
    <script src="public/content/jquery.min.js"></script>
    <script src="public/js/bootstrap.min.js"></script>
    <link href="public/css/style.css" rel="stylesheet" type="text/css" media="all" />
    <link href="public/css/header.css" rel="stylesheet" type="text/css" media="all" />
    <link href="public/css/livechat.css" rel="stylesheet" type="text/css" media="all" />
    <script type="application/x-javascript">
        addEventListener("load", function() {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <link href="public/css/memenu.css" rel="stylesheet" type="text/css" media="all" />

</head>

<body>
    <div class="top_bg" id="top1">
        <div class="container">
            <div class="header_top-sec">
                <div class="top_right">
                    <ul>
                        <li><a href="intro">Hướng dẫn Order </a></li>
                        |
                        <li><a href="contact">Liên Hệ</a></li>
                    </ul>
                </div>
                <div class="top_right" style="padding-left: 2em;">
                </div>
                <div class="top_left">
                    <form style="margin-bottom:0em " action="http://localhost/ShopOnline/search/" method="get" onsubmit="return false;">
                        <input type=search name='q' id='q' value="Nhập từ khóa..." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Nhập từ khóa...';}">
                        <input type="submit" value="Tìm kiếm" onclick="window.location.href=this.form.action + this.form.q.value;" class="input-search" />
                    </form>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
    <div class="header-top">
        <div class="header-bottom">
            <div class="container">
                <div class="logo">
                    <a href="home">
                        <h1>CT Computer</h1>
                    </a>
                </div>
                <div class="top-nav">
                    <ul class="memenu skyblue">
                        <li><a href="home">Trang chủ</a></li>
                                                                                    <li class="grid"><a href="group/1-macbook.html">Macbook</a>
                                    <div class="mepanel">
                                        <ul class="row">
                                                                            </li>
                                                                    <li class="col1 me-one">
                                        <h4>
                                            <a href="category/1-macbookair.html">Macbook Air</a>
                                        </h4>
                                    </li>
                                                                    <li class="col1 me-one">
                                        <h4>
                                            <a href="category/2-macbookpro.html">Macbook Pro</a>
                                        </h4>
                                    </li>
                                                    </ul>
                </div>
                </li>
                                                                                <li class="grid"><a href="group/2-dell.html">Dell</a>
                                    <div class="mepanel">
                                        <ul class="row">
                                                                            </li>
                                                                    <li class="col1 me-one">
                                        <h4>
                                            <a href="category/3-inspiron.html">Inspiron</a>
                                        </h4>
                                    </li>
                                                                    <li class="col1 me-one">
                                        <h4>
                                            <a href="category/4-vostro.html">Vostro</a>
                                        </h4>
                                    </li>
                                                    </ul>
                </div>
                </li>
                                                                <li class="grid"><a href="group/3-chuot.html">Chuột</a>
                </li>
                            <li><a href="livesport">Live</a></li>
        </ul>
            </div>
            <div class="cart box_1">
                <a href="cart"><i class="glyphicon glyphicon-shopping-cart"></i> Giỏ hàng : 0 sp</a>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
    </div>
<div class="banner">
    <div class="col-sm-3 banner-mat">
        <image class="img-responsive" src="http://localhost/ShopOnline/public/upload/images/banner-1-banner-trai.png?time=1577801623" alt="banner-1-banner-trai.png"/ >    </div>
    <div class="col-sm-6 matter-banner">
        <div class="slider">
            <div class="callbacks_container">
                <ul class="rslides" id="slider">
                                            <li>
                            <image src="http://localhost/ShopOnline/public/upload/images/image1-1-banner-trai.png?time=1577801623" alt="image1-1-banner-trai.png"/ >
                        </li>
                                            <li>
                            <image src="http://localhost/ShopOnline/public/upload/images/image2-1-banner-trai.png?time=1577801623" alt="image2-1-banner-trai.png"/ >
                        </li>
                                            <li>
                            <image src="http://localhost/ShopOnline/public/upload/images/image3-1-banner-trai.png?time=1577801623" alt="image3-1-banner-trai.png"/ >
                        </li>
                                            <li>
                            <image src="http://localhost/ShopOnline/public/upload/images/image4-1-banner-trai.png?time=1577801623" alt="image4-1-banner-trai.png"/ >
                        </li>
                                    </ul>
            </div>
        </div>
    </div>
    <div class="col-sm-3 banner-mat">
        <image class="img-responsive" src="http://localhost/ShopOnline/public/upload/images/banner-2-banner-phai.png?time=1577801623" alt="banner-2-banner-phai.png"/ >    </div>
    <div class="clearfix"></div>
</div><div class="shoping">
    <div class="container">
        <div class="shpng-grids">
            <div class="col-md-4 shpng-grid">
                <h3>Free Shipping</h3>
                <p>Miễn phí giao hàng trong phạm vi 10km</p>
            </div>
            <div class="col-md-4 shpng-grid">
                <h3>Order Return</h3>
                <p>Giao hàng order trong vòng 14 ngày</p>
            </div>
            <div class="col-md-4 shpng-grid">
                <h3>COD</h3>
                <p>Thanh toán bằng tiền mặt hoặc chuyển khoản</p>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div><div class="arrivals">
    <div class="container">
        <div class="block-title">
            <a class="view-all-product" href="type/1-san-pham-order.html">VIEW ALL<span> </span></a>  <h5
                class="block-title-name"><a style="color: #FFFFFF" href="type/1-san-pham-order.html">SẢN PHẨM NỔI BẬT</a></h5>
        </div>
        <div class="feature-grids" style="background-color:#ffffff">
                                        <div class="col-md-3 feature-grid jewel">
                    <a href="product/1-macbookair13inch.html" class="screenshot"
                       rel="public/upload/product/macbook-air-mqd32_3.jpg"><image src="public/upload/product/macbook-air-mqd32_3.jpg?time=1577801623"alt="macbook-air-mqd32_3.jpg" />                    </a>

                    <div class="arrival-info">
                        <h4>Apple MacBook Air 13 inch 128GB MQD32 Chính hãng (2017)</h4>

                        <p>Giá bán : 20.300.300 vnđ</p>
                    </div>
                    <div class="viw">
                        <a href="product/view/1-macbookair13inch.html"><span
                                class="glyphicon glyphicon-eye-open"
                                aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                </div>
                            <div class="col-md-3 feature-grid jewel">
                    <a href="product/3-macbookair13inchmree2.html" class="screenshot"
                       rel="public/upload/product/macbook-air-13-mree2.jpg"><image src="public/upload/product/macbook-air-13-mree2.jpg?time=1577801623"alt="macbook-air-13-mree2.jpg" />                    </a>

                    <div class="arrival-info">
                        <h4>Apple MacBook Air 13 inch 128GB Vàng MREE2 Chính hãng</h4>

                        <p>Giá bán : 2.550.000 vnđ</p>
                    </div>
                    <div class="viw">
                        <a href="product/view/3-macbookair13inchmree2.html"><span
                                class="glyphicon glyphicon-eye-open"
                                aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                </div>
                            <div class="col-md-3 feature-grid jewel">
                    <a href="product/6-macbookairsilver13inch.html" class="screenshot"
                       rel="public/upload/product/macbook-air-13-2019-silver-1.png"><image src="public/upload/product/macbook-air-13-2019-silver-1.png?time=1577801623"alt="macbook-air-13-2019-silver-1.png" />                    </a>

                    <div class="arrival-info">
                        <h4>Macbook Air 13 128GB 2019 Bạc (MVFK2)</h4>

                        <p>Giá bán : 26.000.000 vnđ</p>
                    </div>
                    <div class="viw">
                        <a href="product/view/6-macbookairsilver13inch.html"><span
                                class="glyphicon glyphicon-eye-open"
                                aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                </div>
                            <div class="col-md-3 feature-grid jewel">
                    <a href="product/11-macbookpro13inch.html" class="screenshot"
                       rel="public/upload/product/mbp13-gray_128gn-mpxq2.jpg"><image src="public/upload/product/mbp13-gray_128gn-mpxq2.jpg?time=1577801623"alt="mbp13-gray_128gn-mpxq2.jpg" />                    </a>

                    <div class="arrival-info">
                        <h4>Apple MacBook Pro 13 inch 128GB MPXQ2 Chính hãng(2017)</h4>

                        <p>Giá bán : 27.000.000 vnđ</p>
                    </div>
                    <div class="viw">
                        <a href="product/view/11-macbookpro13inch.html"><span
                                class="glyphicon glyphicon-eye-open"
                                aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                </div>
                            <div class="col-md-3 feature-grid jewel">
                    <a href="product/13-macbookprotouch13inch.html" class="screenshot"
                       rel="public/upload/product/mbp13touch-silver-37cu-256gb_geo_us_4.jpg"><image src="public/upload/product/mbp13touch-silver-37cu-256gb_geo_us_4.jpg?time=1577801623"alt="mbp13touch-silver-37cu-256gb_geo_us_4.jpg" />                    </a>

                    <div class="arrival-info">
                        <h4>Apple Macbook Pro 13 256GB 2019 Bạc Chính hãng (MUHR2)</h4>

                        <p>Giá bán : 37.500.000 vnđ</p>
                    </div>
                    <div class="viw">
                        <a href="product/view/13-macbookprotouch13inch.html"><span
                                class="glyphicon glyphicon-eye-open"
                                aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                </div>
                            <div class="col-md-3 feature-grid jewel">
                    <a href="product/14-dellinspiron14n3480.html" class="screenshot"
                       rel="public/upload/product/dellinspiron14n3480-8145.jpg"><image src="public/upload/product/dellinspiron14n3480-8145.jpg?time=1577801623"alt="dellinspiron14n3480-8145.jpg" />                    </a>

                    <div class="arrival-info">
                        <h4>Laptop Dell Inspiron 14 N3480 - 8145(i3-8145U / 4GB/ 1TB)</h4>

                        <p>Giá bán : 10.900.000 vnđ</p>
                    </div>
                    <div class="viw">
                        <a href="product/view/14-dellinspiron14n3480.html"><span
                                class="glyphicon glyphicon-eye-open"
                                aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                </div>
                            <div class="col-md-3 feature-grid jewel">
                    <a href="product/15-dellvostro155581.html" class="screenshot"
                       rel="public/upload/product/dellvostro155581.jpg"><image src="public/upload/product/dellvostro155581.jpg?time=1577801623"alt="dellvostro155581.jpg" />                    </a>

                    <div class="arrival-info">
                        <h4>Laptop Dell Vostro 15 5581 (70175950)(i5-8265U / 4G/ 1TB / 15.6 FHD)</h4>

                        <p>Giá bán : 16.490.000 vnđ</p>
                    </div>
                    <div class="viw">
                        <a href="product/view/15-dellvostro155581.html"><span
                                class="glyphicon glyphicon-eye-open"
                                aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                </div>
                            <div class="col-md-3 feature-grid jewel">
                    <a href="product/17-dellvostro346870161069.html" class="screenshot"
                       rel="public/upload/product/dellvostro346870161069jpg.jpg"><image src="public/upload/product/dellvostro346870161069jpg.jpg?time=1577801623"alt="dellvostro346870161069jpg.jpg" />                    </a>

                    <div class="arrival-info">
                        <h4>Laptop Dell Vostro 3568 (VTI32072W)(i3-7020U / 4GB/ 1TB)</h4>

                        <p>Giá bán : 10.590.000 vnđ</p>
                    </div>
                    <div class="viw">
                        <a href="product/view/17-dellvostro346870161069.html"><span
                                class="glyphicon glyphicon-eye-open"
                                aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                </div>
                            <div class="col-md-3 feature-grid jewel">
                    <a href="product/19-dellvostro155581vrf6j1.html" class="screenshot"
                       rel="public/upload/product/dellvostro15-5581-vrf6j1.jpg"><image src="public/upload/product/dellvostro15-5581-vrf6j1.jpg?time=1577801623"alt="dellvostro15-5581-vrf6j1.jpg" />                    </a>

                    <div class="arrival-info">
                        <h4>Laptop Dell Vostro 15 5581 (VRF6J1)(i5-8265U /4GB/ 1TB/ VGA 2GD5_MX130)</h4>

                        <p>Giá bán : 17.190.000 vnđ</p>
                    </div>
                    <div class="viw">
                        <a href="product/view/19-dellvostro155581vrf6j1.html"><span
                                class="glyphicon glyphicon-eye-open"
                                aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                </div>
                            <div class="col-md-3 feature-grid jewel">
                    <a href="product/21-dellinspiron3593.html" class="screenshot"
                       rel="public/upload/product/dell-inspiron-3593-70197457-i5-1035g1.jpg"><image src="public/upload/product/dell-inspiron-3593-70197457-i5-1035g1.jpg?time=1577801623"alt="dell-inspiron-3593-70197457-i5-1035g1.jpg" />                    </a>

                    <div class="arrival-info">
                        <h4>Laptop Dell Inspiron 3593 (70197457)(i5-1035G1 / 4 GB/ 1 TB HDD/ 15.6 FHD/ VGA 2 GB)</h4>

                        <p>Giá bán : 14.990.000 vnđ</p>
                    </div>
                    <div class="viw">
                        <a href="product/view/21-dellinspiron3593.html"><span
                                class="glyphicon glyphicon-eye-open"
                                aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                </div>
                            <div class="col-md-3 feature-grid jewel">
                    <a href="product/22-laptopnew1.html" class="screenshot"
                       rel="public/upload/product/inspiron-3481-laptopnew1.jpg"><image src="public/upload/product/inspiron-3481-laptopnew1.jpg?time=1577801623"alt="inspiron-3481-laptopnew1.jpg" />                    </a>

                    <div class="arrival-info">
                        <h4>Laptop Dell Inspiron 3481 70183901(i3-7020U / 4GB/ 1TB/ VGA 2GB)</h4>

                        <p>Giá bán : 10.990.000 vnđ</p>
                    </div>
                    <div class="viw">
                        <a href="product/view/22-laptopnew1.html"><span
                                class="glyphicon glyphicon-eye-open"
                                aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                </div>
                            <div class="col-md-3 feature-grid jewel">
                    <a href="product/23-dellvostro5581a.html" class="screenshot"
                       rel="public/upload/product/dellvostro5581a-p77f001.jpg"><image src="public/upload/product/dellvostro5581a-p77f001.jpg?time=1577801623"alt="dellvostro5581a-p77f001.jpg" />                    </a>

                    <div class="arrival-info">
                        <h4>Laptop Dell Vostro 5581A P77F001(i7-8565U / 8GB/ 256GB/ 15.6 FHD)</h4>

                        <p>Giá bán : 24.990.000 vnđ</p>
                    </div>
                    <div class="viw">
                        <a href="product/view/23-dellvostro5581a.html"><span
                                class="glyphicon glyphicon-eye-open"
                                aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                </div>
                            <div class="col-md-3 feature-grid jewel">
                    <a href="product/28-applemousemagicmouse2.html" class="screenshot"
                       rel="public/upload/product/applemousemagicmouse2.jpg"><image src="public/upload/product/applemousemagicmouse2.jpg?time=1577801623"alt="applemousemagicmouse2.jpg" />                    </a>

                    <div class="arrival-info">
                        <h4>Chuột Apple Magic Mouse 2 MLA02 Chính hãng(PKMB.001)</h4>

                        <p>Giá bán : 2.000.000 vnđ</p>
                    </div>
                    <div class="viw">
                        <a href="product/view/28-applemousemagicmouse2.html"><span
                                class="glyphicon glyphicon-eye-open"
                                aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                </div>
                            <div class="col-md-3 feature-grid jewel">
                    <a href="product/29-Applemagicmouse2MRME2.html" class="screenshot"
                       rel="public/upload/product/Applemagicmouse2MRME2.jpg"><image src="public/upload/product/Applemagicmouse2MRME2.jpg?time=1577801623"alt="Applemagicmouse2MRME2.jpg" />                    </a>

                    <div class="arrival-info">
                        <h4>Chuột Apple Magic Mouse 2 MRME2 Chính hãng(PKMB.001)</h4>

                        <p>Giá bán : 2.990.000 vnđ</p>
                    </div>
                    <div class="viw">
                        <a href="product/view/29-Applemagicmouse2MRME2.html"><span
                                class="glyphicon glyphicon-eye-open"
                                aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                </div>
                            <div class="col-md-3 feature-grid jewel">
                    <a href="product/30-logitechg903.html" class="screenshot"
                       rel="public/upload/product/logitechg903.jpg"><image src="public/upload/product/logitechg903.jpg?time=1577801623"alt="logitechg903.jpg" />                    </a>

                    <div class="arrival-info">
                        <h4>Chuột chơi Game không dây Logitech G903(MB.146)</h4>

                        <p>Giá bán : 2.900.000 vnđ</p>
                    </div>
                    <div class="viw">
                        <a href="product/view/30-logitechg903.html"><span
                                class="glyphicon glyphicon-eye-open"
                                aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                </div>
                            <div class="col-md-3 feature-grid jewel">
                    <a href="product/31-logitechg502hero.html" class="screenshot"
                       rel="public/upload/product/logitechg502hero.jpg"><image src="public/upload/product/logitechg502hero.jpg?time=1577801623"alt="logitechg502hero.jpg" />                    </a>

                    <div class="arrival-info">
                        <h4>Chuột chơi Game có dây Logitech G502 Hero(MB.144)</h4>

                        <p>Giá bán : 1.500.000 vnđ</p>
                    </div>
                    <div class="viw">
                        <a href="product/view/31-logitechg502hero.html"><span
                                class="glyphicon glyphicon-eye-open"
                                aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                </div>
                        <div class="clearfix"></div>
        </div>

    </div>
</div><div class="shoping" style="padding:0px">
<div class="container">
    <a href="home">
        <figure >
            <image class="img-responsive" src="http://localhost/ShopOnline/public/upload/images/advertise-3-banner-quang-cao-ngang-1.png?time=1577801623" alt="advertise-3-banner-quang-cao-ngang-1.png"/ >        </figure>
    </a>
</div>
</div>


<div class="featured">
    <div class="container">
        <div class="block-title">
            <a class="view-all-product" href="type/2-san-pham-moi.html">VIEW ALL<span> </span></a>  <h5
                class="block-title-name"><a style="color: #FFFFFF" href="type/2-san-pham-moi.html">SẢN PHẨM MỚI</a></h5>
        </div>
        <div class="feature-grids" style="background-color:#ffffff">
                        
                <div class="col-md-3 feature-grid jewel">
                    <a href="product/2-macbookair13goldinch" class="screenshot"
                       rel="public/upload/product/macbook-air-13-2019-gold-1.jpg"><image src="public/upload/product/macbook-air-13-2019-gold-1.jpg?time=1577801623"alt="macbook-air-13-2019-gold-1.jpg" />                    </a>

                    <div class="arrival-info">
                        <h4>Macbook Air 13 128GB 2019 Vàng (MVFM2)</h4>

                        <p>Giá bán : 26.000.000 vnđ</p>
                    </div>

                    <div class="viw">
                        <a href="product/2-macbookair13goldinch.html"><span
                                class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                                        </a>
                </div>
            
                <div class="col-md-3 feature-grid jewel">
                    <a href="product/4-macbookairmrea2" class="screenshot"
                       rel="public/upload/product/macbook-air-13-silver-mrea2.jpg"><image src="public/upload/product/macbook-air-13-silver-mrea2.jpg?time=1577801623"alt="macbook-air-13-silver-mrea2.jpg" />                    </a>

                    <div class="arrival-info">
                        <h4>Apple MacBook Air 13 inch 128GB MREA2 Bạc Chính hãng(2018)</h4>

                        <p>Giá bán : 26.000.000 vnđ</p>
                    </div>

                    <div class="viw">
                        <a href="product/4-macbookairmrea2.html"><span
                                class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                                        </a>
                </div>
            
                <div class="col-md-3 feature-grid jewel">
                    <a href="product/5-macbookair13inchgrey" class="screenshot"
                       rel="public/upload/product/macbook-air-13-2019-grey-1.png"><image src="public/upload/product/macbook-air-13-2019-grey-1.png?time=1577801623"alt="macbook-air-13-2019-grey-1.png" />                    </a>

                    <div class="arrival-info">
                        <h4>Macbook Air 13 128GB 2019 Xám (MVFH2)</h4>

                        <p>Giá bán : 20.300.300 vnđ</p>
                    </div>

                    <div class="viw">
                        <a href="product/5-macbookair13inchgrey.html"><span
                                class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                                        </a>
                </div>
            
                <div class="col-md-3 feature-grid jewel">
                    <a href="product/8-macbookair13silver256inch" class="screenshot"
                       rel="public/upload/product/macbook-air-13-2019-silver-1_1.png"><image src="public/upload/product/macbook-air-13-2019-silver-1_1.png?time=1577801623"alt="macbook-air-13-2019-silver-1_1.png" />                    </a>

                    <div class="arrival-info">
                        <h4>Apple Macbook Air 13inch 256GB Bạc MREC2 Chính hãng(2018)</h4>

                        <p>Giá bán : 33.500.000 vnđ</p>
                    </div>

                    <div class="viw">
                        <a href="product/8-macbookair13silver256inch.html"><span
                                class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                                        </a>
                </div>
            
                <div class="col-md-3 feature-grid jewel">
                    <a href="product/9-macbookairmvf213inch" class="screenshot"
                       rel="public/upload/product/macbook-air-13-2019-grey-256_mvfj2.png"><image src="public/upload/product/macbook-air-13-2019-grey-256_mvfj2.png?time=1577801623"alt="macbook-air-13-2019-grey-256_mvfj2.png" />                    </a>

                    <div class="arrival-info">
                        <h4>Macbook Air 13 256GB 2019 Xám (MVFJ2)</h4>

                        <p>Giá bán : 32.000.000 vnđ</p>
                    </div>

                    <div class="viw">
                        <a href="product/9-macbookairmvf213inch.html"><span
                                class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                                        </a>
                </div>
            
                <div class="col-md-3 feature-grid jewel">
                    <a href="product/10-macbookair13inch" class="screenshot"
                       rel="public/upload/product/macbook-air-13-2018-grey-256gb-mre92.png"><image src="public/upload/product/macbook-air-13-2018-grey-256gb-mre92.png?time=1577801623"alt="macbook-air-13-2018-grey-256gb-mre92.png" />                    </a>

                    <div class="arrival-info">
                        <h4>Apple Macbook Air 13inch 256GB Xám MRE92 Chính hãng(2018)</h4>

                        <p>Giá bán : 31.000.000 vnđ</p>
                    </div>

                    <div class="viw">
                        <a href="product/10-macbookair13inch.html"><span
                                class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                                        </a>
                </div>
            
                <div class="col-md-3 feature-grid jewel">
                    <a href="product/16-delllatitude7490" class="screenshot"
                       rel="public/upload/product/delllatitude7490.jpg"><image src="public/upload/product/delllatitude7490.jpg?time=1577801623"alt="delllatitude7490.jpg" />                    </a>

                    <div class="arrival-info">
                        <h4>Laptop Dell Latitude 7490 70156592(i7-8650U / 8GB/ 256GB)</h4>

                        <p>Giá bán : 30.990.000 vnđ</p>
                    </div>

                    <div class="viw">
                        <a href="product/16-delllatitude7490.html"><span
                                class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                                        </a>
                </div>
            
                <div class="col-md-3 feature-grid jewel">
                    <a href="product/18-dellinspiron3480n4i5107w" class="screenshot"
                       rel="public/upload/product/dellinspiron3480n4i5107w.jpg"><image src="public/upload/product/dellinspiron3480n4i5107w.jpg?time=1577801623"alt="dellinspiron3480n4i5107w.jpg" />                    </a>

                    <div class="arrival-info">
                        <h4>Laptop Dell Inspiron 3480 N4I5107W(i5-8265U / 4G/ 1TB)</h4>

                        <p>Giá bán : 12.990.000 vnđ</p>
                    </div>

                    <div class="viw">
                        <a href="product/18-dellinspiron3480n4i5107w.html"><span
                                class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                                        </a>
                </div>
            
                <div class="col-md-3 feature-grid jewel">
                    <a href="product/24-ínpironn3476" class="screenshot"
                       rel="public/upload/product/dell-inspiron-n3476-c4i51121w-1.png"><image src="public/upload/product/dell-inspiron-n3476-c4i51121w-1.png?time=1577801623"alt="dell-inspiron-n3476-c4i51121w-1.png" />                    </a>

                    <div class="arrival-info">
                        <h4>Laptop Dell Inspiron N3476 C4I51121W(i5-8250U / 4GB/ 1TB)</h4>

                        <p>Giá bán : 12.990.000 vnđ</p>
                    </div>

                    <div class="viw">
                        <a href="product/24-ínpironn3476.html"><span
                                class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                                        </a>
                </div>
            
                <div class="col-md-3 feature-grid jewel">
                    <a href="product/25-dellinspiron7591" class="screenshot"
                       rel="public/upload/product/dellInspiron-7591-kj2g41.jpg"><image src="public/upload/product/dellInspiron-7591-kj2g41.jpg?time=1577801623"alt="dellInspiron-7591-kj2g41.jpg" />                    </a>

                    <div class="arrival-info">
                        <h4>Laptop Dell Inspiron 7591 KJ2G41(I7 9750H 8GB / 256GB SSD/15.6FHD / VGA 3GB)</h4>

                        <p>Giá bán : 29.990.000 vnđ</p>
                    </div>

                    <div class="viw">
                        <a href="product/25-dellinspiron7591.html"><span
                                class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                                        </a>
                </div>
            
                <div class="col-md-3 feature-grid jewel">
                    <a href="product/26-dellinspiron5480" class="screenshot"
                       rel="public/upload/product/dell-inspiron-5480-n5480a.jpg"><image src="public/upload/product/dell-inspiron-5480-n5480a.jpg?time=1577801623"alt="dell-inspiron-5480-n5480a.jpg" />                    </a>

                    <div class="arrival-info">
                        <h4>Laptop Dell Inspiron N5480B(i5-8265U / 8 GB/ 256 GB SSD/ 14.0 Full HD)</h4>

                        <p>Giá bán : 15.990.000 vnđ</p>
                    </div>

                    <div class="viw">
                        <a href="product/26-dellinspiron5480.html"><span
                                class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                                        </a>
                </div>
            
                <div class="col-md-3 feature-grid jewel">
                    <a href="product/27-dellinspiron359370197459" class="screenshot"
                       rel="public/upload/product/dellinspiron3593-70197459.jpg"><image src="public/upload/product/dellinspiron3593-70197459.jpg?time=1577801623"alt="dellinspiron3593-70197459.jpg" />                    </a>

                    <div class="arrival-info">
                        <h4>Laptop Dell Inspiron 3593 (70197459)(i7-1065G7 / 8 GB/ 512 GB SSD/ 15.6 FHD/ VGA 2 GB)</h4>

                        <p>Giá bán : 25.500.000 vnđ</p>
                    </div>

                    <div class="viw">
                        <a href="product/27-dellinspiron359370197459.html"><span
                                class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                                        </a>
                </div>
            
                <div class="col-md-3 feature-grid jewel">
                    <a href="product/32-g603logitech" class="screenshot"
                       rel="public/upload/product/chu_t-gaming-logitech-g603-lightspeed-wireless.jpg"><image src="public/upload/product/chu_t-gaming-logitech-g603-lightspeed-wireless.jpg?time=1577801623"alt="chu_t-gaming-logitech-g603-lightspeed-wireless.jpg" />                    </a>

                    <div class="arrival-info">
                        <h4>Chuột chơi game không dây Logitech G603 Đen(MA.283.B)</h4>

                        <p>Giá bán : 2.900.000 vnđ</p>
                    </div>

                    <div class="viw">
                        <a href="product/32-g603logitech.html"><span
                                class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                                        </a>
                </div>
            
                <div class="col-md-3 feature-grid jewel">
                    <a href="product/33-applemousemagicmousecu" class="screenshot"
                       rel="public/upload/product/applemousemagicmouse2.jpg"><image src="public/upload/product/applemousemagicmouse2.jpg?time=1577801623"alt="applemousemagicmouse2.jpg" />                    </a>

                    <div class="arrival-info">
                        <h4>Chuột Apple Magic Mouse 2 Bạc Cũ(PKMB.001)</h4>

                        <p>Giá bán : 1.600.000 vnđ</p>
                    </div>

                    <div class="viw">
                        <a href="product/33-applemousemagicmousecu.html"><span
                                class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                                        </a>
                </div>
            
                <div class="col-md-3 feature-grid jewel">
                    <a href="product/34-chuotlogitechg102" class="screenshot"
                       rel="public/upload/product/chuotlogitechg102.jpg"><image src="public/upload/product/chuotlogitechg102.jpg?time=1577801623"alt="chuotlogitechg102.jpg" />                    </a>

                    <div class="arrival-info">
                        <h4>Chuột chơi Game có dây Logitech G102(MB.143)</h4>

                        <p>Giá bán : 440.000 vnđ</p>
                    </div>

                    <div class="viw">
                        <a href="product/34-chuotlogitechg102.html"><span
                                class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                                        </a>
                </div>
            
                <div class="col-md-3 feature-grid jewel">
                    <a href="product/35-Applemagicmousedakichhoat" class="screenshot"
                       rel="public/upload/product/Applemagicmouse2MRME2.jpg"><image src="public/upload/product/Applemagicmouse2MRME2.jpg?time=1577801623"alt="Applemagicmouse2MRME2.jpg" />                    </a>

                    <div class="arrival-info">
                        <h4>Chuột Apple Magic Mouse 2 MRME2</h4>

                        <p>Giá bán : 2.500.000 vnđ</p>
                    </div>

                    <div class="viw">
                        <a href="product/35-Applemagicmousedakichhoat.html"><span
                                class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                                        </a>
                </div>
                    </div>
    </div>
</div><div class="featured">
    <div class="container">
        <div class="block-title">
            <a class="view-all-product" href="type/3-san-pham-khuyen-mai.html">VIEW ALL<span> </span></a>  <h5
                class="block-title-name"><a style="color: #FFFFFF" href="type/3-san-pham-khuyen-mai.html">SẢN PHẨM KHUYẾN MẠI</a></h5>
        </div>
        <div class="feature-grids" style="background-color:#ffffff">
                                        <div class="col-md-3 feature-grid jewel">
                    <a href="product/7-logitechg502hero.html" class="screenshot"
                       rel="public/upload/product/macbook-air-13-2019-silver-1_1.png"><image src="public/upload/product/macbook-air-13-2019-silver-1_1.png?time=1577801623"alt="macbook-air-13-2019-silver-1_1.png" />                    </a>

                    <div class="arrival-info">
                        <h4>Macbook Air 13 256GB 2019 Bạc (MVFL2)</h4>
                    <span class="pric1"><del>Giá bán
                            : 32.000.000 vnđ
                        </del></span>

                        <p>Giá khuyến mại : 32.000.000                            vnđ</p>
                    </div>

                    <div class="viw">
                        <a href="product/7-macbookair13silvermvfl2inch.html"><span
                                class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                                            <div class="shrt">
                            <a href="product/7-macbookair13silvermvfl2inch.html"><span
                                    class="glyphicon glyphicon-star"
                                    aria-hidden="true"></span>Saleoff 0%</a>
                        </div>
                                        </a>
                </div>
                            <div class="col-md-3 feature-grid jewel">
                    <a href="product/12-logitechg502hero.html" class="screenshot"
                       rel="public/upload/product/mbp13touch-muhp2-256-2019_geo_us.jpg"><image src="public/upload/product/mbp13touch-muhp2-256-2019_geo_us.jpg?time=1577801623"alt="mbp13touch-muhp2-256-2019_geo_us.jpg" />                    </a>

                    <div class="arrival-info">
                        <h4>Apple Macbook Pro 13 256GB 2019 Xám Chính hãng (MUHP2)</h4>
                    <span class="pric1"><del>Giá bán
                            : 38.000.000 vnđ
                        </del></span>

                        <p>Giá khuyến mại : 38.000.000                            vnđ</p>
                    </div>

                    <div class="viw">
                        <a href="product/12-macbookpromuph213inch.html"><span
                                class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                                            <div class="shrt">
                            <a href="product/12-macbookpromuph213inch.html"><span
                                    class="glyphicon glyphicon-star"
                                    aria-hidden="true"></span>Saleoff 0%</a>
                        </div>
                                        </a>
                </div>
                            <div class="col-md-3 feature-grid jewel">
                    <a href="product/20-logitechg502hero.html" class="screenshot"
                       rel="public/upload/product/dell_xps_15_7580.jpg"><image src="public/upload/product/dell_xps_15_7580.jpg?time=1577801623"alt="dell_xps_15_7580.jpg" />                    </a>

                    <div class="arrival-info">
                        <h4>Laptop Dell XPS 15 7590(i7-9750H / 16 GB/ 512 GB SSD/ 15.6 TOUCH 4K/ VGA 4GB)</h4>
                    <span class="pric1"><del>Giá bán
                            : 52.290.000 vnđ
                        </del></span>

                        <p>Giá khuyến mại : 52.290.000                            vnđ</p>
                    </div>

                    <div class="viw">
                        <a href="product/20-dellxps15.html"><span
                                class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                                            <div class="shrt">
                            <a href="product/20-dellxps15.html"><span
                                    class="glyphicon glyphicon-star"
                                    aria-hidden="true"></span>Saleoff 0%</a>
                        </div>
                                        </a>
                </div>
                            <div class="col-md-3 feature-grid jewel">
                    <a href="product/36-logitechg502hero.html" class="screenshot"
                       rel="public/upload/product/mtp62_vw_34fr_watch-40-alum-spacegray-nc-5s_vw_34fr_wf_co_geo_sg.jpg"><image src="public/upload/product/mtp62_vw_34fr_watch-40-alum-spacegray-nc-5s_vw_34fr_wf_co_geo_sg.jpg?time=1577801623"alt="mtp62_vw_34fr_watch-40-alum-spacegray-nc-5s_vw_34fr_wf_co_geo_sg.jpg" />                    </a>

                    <div class="arrival-info">
                        <h4>Apple Watch 5 44mm (GPS) Viền Nhôm Xám - Dây Đen Chính hãng (MWVF2)</h4>
                    <span class="pric1"><del>Giá bán
                            : 11.990.000 vnđ
                        </del></span>

                        <p>Giá khuyến mại : 11.990.000                            vnđ</p>
                    </div>

                    <div class="viw">
                        <a href="product/36-Applewatch.html"><span
                                class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>Quick
                            View</a>
                    </div>
                                            <div class="shrt">
                            <a href="product/36-Applewatch.html"><span
                                    class="glyphicon glyphicon-star"
                                    aria-hidden="true"></span>Saleoff 0%</a>
                        </div>
                                        </a>
                </div>
                    </div>
    </div>
</div>

<div class="footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-sm-3 address wow fadeInUp" data-wow-duration="2s" data-wow-delay=".1s">
                <h1>
                    contact info
                </h1>
                <address>
                    <p><i class="fa fa-home pr-10"></i> Address:km9, Nguyen Trai Street, Nam Tu Liem, Ha Noi</p>

                    <p><i class="fa fa-globe pr-10"></i> Nam Tu Liem, Ha Noi</p>

                    <p><i class="fa fa-mobile pr-10"></i>  Mobile : 0123456789</p>

                    <p><i class="fa fa-phone pr-10"></i> Phone : 0363886688</p>

                </address>
            </div>
            <div class="col-lg-3 col-sm-3 address wow fadeInUp" data-wow-duration="2s" data-wow-delay=".1s">
                <h1>
                    Social
                </h1>
                <address>

                    <p><i class="fa fa-envelope pr-10"></i> Email : <a href="javascript:;">CTcomputerCSKH@gmail.com</a></p>

                    <p><i class="fa fa-facebook pr-10"></i>  Facebook : <a href="javascript:;">Facebook.com</a></p>

                    <p><i class="fa fa-envelope pr-10"></i> Zalo : <a href="javascript:;">0123456789</a></p>

                    <p><i class="fa fa-skype pr-10"></i> Skype :<a href="javascript:;">CTcomputershop</a></p>
                </address>
            </div>
            <div class="col-lg-3 col-sm-3">
                <div class="page-footer wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s">
                    <h1>
                        order
                    </h1>
                    <ul class="page-footer-list">
                        <li>
                            <i class="fa fa-angle-right"></i>
                            <a href="intro">About Us</a>
                        </li>
                        <li>
                            <i class="fa fa-angle-right"></i>
                            <a href="intro">Order Guide</a>
                        </li>
                        <li>
                            <i class="fa fa-angle-right"></i>
                            <a href="intro">Shipping</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3 col-sm-3">
                <div class="page-footer wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s">
                    <h1>
                        Categories
                    </h1>
                    <ul class="page-footer-list">
                                                                                    <li>
                                    <i class="fa fa-angle-right"></i>
                                    <a href="group/1-macbook.html"> Macbook</a>
                                </li>
                                                            <li>
                                    <i class="fa fa-angle-right"></i>
                                    <a href="group/2-dell.html"> Dell</a>
                                </li>
                                                            <li>
                                    <i class="fa fa-angle-right"></i>
                                    <a href="group/3-chuot.html"> Chuột</a>
                                </li>
                                                                        </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- footer end -->
<!--small footer start -->
<div class="footer-small">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-sm-6 pull-right">
                <ul class="social-link-footer list-unstyled">
                    <li class="wow flipInX" data-wow-duration="2s" data-wow-delay=".1s"><a href="#"><i
                                class="fa fa-facebook"></i></a></li>
                    <li class="wow flipInX" data-wow-duration="2s" data-wow-delay=".2s"><a href="#"><i
                                class="fa fa-google-plus"></i></a></li>
                    <li class="wow flipInX" data-wow-duration="2s" data-wow-delay=".3s"><a href="#"><i
                                class="fa fa-dribbble"></i></a></li>
                    <li class="wow flipInX" data-wow-duration="2s" data-wow-delay=".4s"><a href="#"><i
                                class="fa fa-linkedin"></i></a></li>
                    <li class="wow flipInX" data-wow-duration="2s" data-wow-delay=".5s"><a href="#"><i
                                class="fa fa-twitter"></i></a></li>
                    <li class="wow flipInX" data-wow-duration="2s" data-wow-delay=".6s"><a href="#"><i
                                class="fa fa-skype"></i></a></li>
                    <li class="wow flipInX" data-wow-duration="2s" data-wow-delay=".7s"><a href="#"><i
                                class="fa fa-github"></i></a></li>
                    <li class="wow flipInX" data-wow-duration="2s" data-wow-delay=".8s"><a href="#"><i
                                class="fa fa-youtube"></i></a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <div class="copyright">
                    <p>&copy; Copyright - CT Computer</p>
                </div>
            </div>
        </div>
    </div>
</div>



<script src="http://localhost/ShopOnline/public/js/responsiveslides.min.js"></script>
<script type="text/javascript" src="http://localhost/ShopOnline/public/js/memenu.js"></script>
<script>
    $('#q').focus(function()
    {
        $(this).attr('data-default', $(this).width());
        $(this).animate({ width:370 }, 'slow');
    }).blur(function()
    {
        var w = $(this).attr('data-default');
        $(this).animate({ width: w }, 'slow');
    });
</script>

<script>
    $(function () {
        $("#slider").responsiveSlides({
            auto: true,
            speed: 500,
            namespace: "callbacks",
            pager: true,
        });
    });
</script>

<script>
    this.screenshotPreview = function () {
        xOffset = 10;
        yOffset = 30;
        $("a.screenshot").hover(function (e) {
                this.t = this.title;
                this.title = "";
                var c = (this.t != "") ? "<br/>" + this.t : "";
                $("body").append("<p id='screenshot'><img src='" + this.rel + "' alt='url preview' width='350' height='500' />" + c + "</p>");
                $("#screenshot")
                    .css("top", (e.pageY - xOffset) + "px")
                    .css("left", (e.pageX + yOffset) + "px")
                    .fadeIn("fast");
            },
            function () {
                this.title = this.t;
                $("#screenshot").remove();
            });
        $("a.screenshot").mousemove(function (e) {
            $("#screenshot")
                .css("top", (e.pageY - xOffset) + "px")
                .css("left", (e.pageX + yOffset) + "px");
        });
    };
</script>

<script>$(document).ready(function () {
        $(".memenu").memenu();
        screenshotPreview();
    });
</script>

</body>
</html>
