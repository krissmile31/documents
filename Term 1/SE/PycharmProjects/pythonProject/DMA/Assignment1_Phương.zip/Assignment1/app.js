
// function onClickChangeBackground(event){
//     ques_selected.classList.add('change-bg-color');
// }

// const { Http2ServerRequest } = require("http2");

// const ques_selected = document.querySelectorAll('input', 'label');
// ques_selected.addEventListener('click', onClickChangeBackground);


function onButtonClickOpenQuiz(event){
    const question = event.currentTarget;
    question.removeEventListener('click', onButtonClickOpenQuiz);

    const openQuiz = document.querySelector('#question');
    const intro = document.querySelector('.intro');
    openQuiz.classList.remove('hidden');
    intro.classList.add('hidden');
    //onOpenQuestion();
 }
const question_btn = document.querySelector('.blue-btn');
question_btn.addEventListener('click', onButtonClickOpenQuiz);

function openQuestion(json){
    const questions = json.questions;
    const show_question = document.querySelector('#question');
    let progress_number = document.createElement('h2');
    let question_name = document.createElement('p');
    let question_form = document.createElement('form');
    
    let count = 0;
    let PROGRESS = [];
    let QUESTION_NAME = [];
    let QUESTION_FORM = [];
    let QUESTIONS = [];
    for(const ques of questions){
        count++;
        // PROGRESS.push('Question ' + count + ' of 10');
        // QUESTION_NAME.push(ques.text);
        // QUESTION_FORM.push(ques.answers);
        QUESTIONS.push(ques);

        progress_number.innerText = 'Question ' + count;
        show_question.appendChild(progress_number);
    }
    // for(let i=0; i<PROGRESS.length; i++){
    //     progress_number.innerText = PROGRESS[i];
    //     show_question.appendChild(progress_number);
    // }
    // console.log(PROGRESS);
    // console.log(QUESTION_NAME);
    // console.log(QUESTION_FORM);
    console.log(QUESTIONS);
    
}

function onResponse(response){
    return response.json();
}

fetch('questions-source.json').then(onResponse).then(openQuestion)
// .catch(function(error){
//     console.log(error);
// });

