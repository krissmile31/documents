
// function onOpenQuestion(json){
//     const open_questions = json.questions;
//     //console.log(open_questions);
//     const question_name = document.querySelector('h2');
//     const answer = document.querySelector('label');

//     for (const ques of open_questions){
//         question_name.textContent = ques.text;
//         console.log(ques.text);
//         // for(const ans in open_questions.answers){
//         //     answer.textContent =  ans;
//         // }
//     }
// }                      

// function onResponse(response){
//     return response.json();
// }

// fetch('questions.json').then(onResponse).then(onOpenQuestion);