const express = require('express');

// dictionary
const KOREAN = {
    '여자': 'woman',
    '남자': 'man',
    '사람': 'person',
    '나무': 'tree',
    '호수': 'lake',
    '구름': 'cloud',
    '땅': 'ground'
};

const app = express();

// serve static files
app.use(express.static('tut05/solution/express-server/public'));

app.get('/hello-world', function (req, res){
    res.end('Hello World!');
});
// test url: http://localhost:8080/hello-world

app.get('/hello', function (req, res){
    const name = req.query.name;

    res.end('Hello '+name+'!');
});
// test url: http://localhost:8080/hello?name=Cong

app.get('/dictionary', function(req, res){
    const key = req.query.key;
    const definition = KOREAN[key];

    res.end(definition);
});
// test url: http://localhost:8080/dictionary?key=여자

app.listen(8080, function (){
    console.log('Server started listening on port 8080!');
});