var http = require('http');
var url = require('url');

http.createServer(function (req, res) {
    const q = url.parse(req.url, true);
    const name = q.query.name;

    res.writeHead(200, {
        'Content-Type': 'text/html',
        'charset': 'utf-8'
    });

    res.end('Hello '+name+'!');

}).listen(8080);

// test url: http://localhost:8080/index.html?name=Cong