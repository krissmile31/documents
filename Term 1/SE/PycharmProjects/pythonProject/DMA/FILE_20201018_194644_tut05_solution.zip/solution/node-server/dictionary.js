var http = require('http');
var url = require('url');

const KOREAN = {
    '여자': 'woman',
    '남자': 'man',
    '사람': 'person',
    '나무': 'tree',
    '호수': 'lake',
    '구름': 'cloud',
    '땅': 'ground'
};

http.createServer(function (req, res) {
    const q = url.parse(req.url, true);
    const key = q.query.key;

    res.writeHead(200, {
        'Content-Type': 'text/html',
        'charset': 'utf-8'
    });

    res.end(KOREAN[key]);
}).listen(8080);

// test url: http://localhost:8080/index.html?dictionary?key=여자