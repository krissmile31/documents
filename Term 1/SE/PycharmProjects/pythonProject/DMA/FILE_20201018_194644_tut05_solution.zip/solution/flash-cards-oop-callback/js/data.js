const KOREAN = {
    '여자': 'woman',
    '남자': 'man',
    '사람': 'person',
    '나무': 'tree',
    '호수': 'lake',
    '구름': 'cloud',
    '땅': 'ground'
};