const flashCardsContainer = document.querySelector('#flashcard-container');
const statusBarContainer = document.querySelector('.status');

const app = new App(flashCardsContainer, statusBarContainer, KOREAN);