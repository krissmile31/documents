class App {
    constructor(flashCardsContainer, statusBarContainer, words) {
        this.flashCardsContainer = flashCardsContainer;
        this.statusBarContainer = statusBarContainer;
        this.words = words;

        // bind events
        this._prevCard = this._prevCard.bind(this);
        this._nextCard = this._nextCard.bind(this);

        this.flashCards = [];
        this._fillFlashCardsContainer();

        // show first card
        this.currentIndex = 0; // array index: range from [0 - this.flashCards.length]
        if (this.flashCards) { // if this.flashCards is not empty
            this.flashCards[this.currentIndex].show();
        }

        // communication between classes: callback functions
        this.statusBar = new StatusBar(statusBarContainer, this.flashCards.length, this._prevCard, this._nextCard);

        // // communication between classes: custom events
        // document.addEventListener('prev-clicked', this._prevCard);
        // document.addEventListener('next-clicked', this._nextCard);
    }

    // return number of words in this.words
    _fillFlashCardsContainer() {
        for (const word in this.words) {
            const definition = this.words[word];
            const card = new FlashCard(this.flashCardsContainer, word, definition);

            this.flashCards.push(card);
        }
    }

    _prevCard() {
        if (this.currentIndex > 0) {
            // hide current flash card
            this.flashCards[this.currentIndex].hide();

            // show prev flash card
            this.currentIndex--;
            this.flashCards[this.currentIndex].show();
        }
    }

    _nextCard() {
        if (this.currentIndex < this.flashCards.length - 1) {
            // hide current flash card
            this.flashCards[this.currentIndex].hide();

            // show next flash card
            this.currentIndex++;
            this.flashCards[this.currentIndex].show();
        }
    }


    // function prevCard() {
    //     const prevCard = card.previousElementSibling; // get prev card

    //     if (prevCard) { // if prev card exists
    //         // hide current card
    //         card.classList.add('hidden');

    //         // show prev card
    //         prevCard.classList.remove('hidden');

    //         // update status index
    //         currentIndex--;
    //         statusIndex.textContent = currentIndex;

    //         btnNext.disabled = false; // enable button next
    //         if (currentIndex === 1) { // if first word
    //             btnPrev.disabled = true; // disable button prev
    //         }

    //         // update card to be current card
    //         card = prevCard;
    //     }
    // }

    // function nextCard() {
    //     const nextCard = card.nextElementSibling; // get next card

    //     if (nextCard) { // if next card exists
    //         // hide current card
    //         card.classList.add('hidden');

    //         // show next card
    //         nextCard.classList.remove('hidden');

    //         // update status index
    //         currentIndex++;
    //         statusIndex.textContent = currentIndex;

    //         btnPrev.disabled = false; // enable button prev
    //         if (currentIndex === numOfWords) { // if last word
    //             btnNext.disabled = true; // disable button next
    //         }

    //         // update card to be current card
    //         card = nextCard;
    //     }
    // }

    // function navigateCards(event) {
    //     const key = event.key;
    //     if (key === 'ArrowLeft') {
    //         prevCard();
    //     } else if (key === 'ArrowRight') {
    //         nextCard();
    //     } else if (key === 'ArrowUp') {
    //         flipCard();
    //     }
    // }

}