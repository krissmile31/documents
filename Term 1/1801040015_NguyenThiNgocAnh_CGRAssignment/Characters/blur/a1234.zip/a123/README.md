## Installation

```bash
$ npm install
```

## Running Server

Put your terminal into src/server

```bash
# development
$ npm run start

# beautify code
$ npm run beautify

# lint
$ npm run lint
```
