import { model, Schema } from 'mongoose';

const schema = new Schema({
  questions:Array,
  completed: Boolean,
  score: Number,
  correctAnswers:Object,
  startAt:Date

});
//----quest
const Attempt = model('Attempt', schema, 'attempts');
export default Attempt;
