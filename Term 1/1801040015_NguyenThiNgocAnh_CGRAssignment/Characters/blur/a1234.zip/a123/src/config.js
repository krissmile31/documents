export const env = {
  host: 'localhost',
  port: 3000,
};

export const dbConnection = {
  host: 'localhost',
  port: 27017,
  database: 'local',
};
